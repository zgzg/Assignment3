
public class main2014302580351 {
	public static void main(String[] args)throws Exception{
		singleThread2014302580351 text = new singleThread2014302580351();
		text.crawler();
		
		crawler2014302580351 crawler1= new crawler2014302580351();
		parsePage2014302580351 parsepage1=new parsePage2014302580351();
		crawler1.start();
		parsepage1.start();
		
	}
}
