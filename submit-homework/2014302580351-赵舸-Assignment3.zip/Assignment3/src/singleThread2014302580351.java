import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class singleThread2014302580351 {
	public static void crawler() throws Exception{ 
	    String[] url= new String[11] ; 
	    long startTimeStamp =  System.currentTimeMillis();
	    int i = 0;
		int m = 0;
		String url1="http://www.wpi.edu/academics/cs/research-interests.html";
		String PhoneNumber;
		String Email;
		
		try {		
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection  con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/assignment3", 
					"root", "123456");			
		    Document  doc = Jsoup.connect(url1).timeout(10000000).get();
		    System.out.println("singleThread start");
		    Element elements2=doc.getElementsByClass("half").first();
		    Elements es=elements2.getElementsByTag("a");
		    for(Element e:es){
		    	url[i] = e.attr("abs:href");
		    	i++;
		    	if(i==11){
		    		break;
		    	}
		    }
		    for(int j=0;j<11;j++){
		    	if(j != 1){
		    	Document doc1 = Jsoup.connect(url[j]).timeout(10000000).get();
		    	Element content = doc1.getElementById("twocol");
		    	Elements content1 = doc1.getElementsByTag("p");
		    	Element content2 = doc1.getElementsByTag("h2").first();
		    	String name = content2.text();
		    	String Introduction = content.text();		    	
		    	String ctt1 = content1.text();
				String regex1 = "(\\d{1}-\\d{3}-\\d{3}-\\d{4})";
				String regex2 = "[a-z]+@([a-z]+)\\.([a-z]+)\\.([a-z]+)|[a-z]+@([a-z]+)\\.([a-z]+)";
		    	Matcher matcher1 = Pattern.compile(regex1).matcher(ctt1);
				if(matcher1.find()){
					PhoneNumber = matcher1.group(0);
				}else{
					PhoneNumber = " ";
				}
				Matcher matcher2 = Pattern.compile(regex2).matcher(ctt1);
				if(matcher2.find()){
					Email = matcher2.group(0);
				}else{
					Email = " ";
				}
				PreparedStatement insertInfor = con.prepareStatement("insert into proinfo2 values(?,?,?,?,?)");
				insertInfor.setInt(1,++m);
				insertInfor.setString(2, name);
				insertInfor.setString(3, PhoneNumber);
				insertInfor.setString(4, Email);
				insertInfor.setString(5, Introduction);
				insertInfor.executeUpdate();																
		    	}
		    	}
		    con.close();
		    
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Processing Time: " + Long.toString(System.currentTimeMillis() - startTimeStamp));
}
	}

	
