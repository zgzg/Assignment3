import java.io.IOException;
import java.sql.DriverManager;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class crawler2014302580351 extends Thread {
	static String url1="http://www.wpi.edu/academics/cs/research-interests.html";
	public static  String[] urlm=new String[11];
	
	
	
	
	
	@SuppressWarnings("static-access")
	public void run(){
		try {
			this.crawler();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
	public static void crawler() throws Exception{
		 
		int i = 0;
		try {		
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection  con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/assignment3", 
					"root", "123456");			
			System.out.println("MultiThread start");
		    Document  doc = Jsoup.connect(url1).timeout(10000000).get();
		    Element elements2=doc.getElementsByClass("half").first();
		    Elements es=elements2.getElementsByTag("a");
		    for(Element e:es){
		    	urlm[i]=e.attr("abs:href");
		    	i++;
		    	if(i==11){
		    		break;
		    	}
		    }
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
}
