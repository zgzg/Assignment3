import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class parsePage2014302580351 extends Thread {
	static String PhoneNumber;
	static String Email;
	static int m=0;
	public static void parsepage() throws Exception{
		java.sql.Connection  con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/assignment3", 
				"root", "123456");
		for(int j=0;j<11;j++){
			if(j != 1){
				while(crawler2014302580351.urlm[j]==null){
				TimeUnit.MILLISECONDS.sleep(10);
			}
				Document doc1 = Jsoup.connect(crawler2014302580351.urlm[j]).timeout(10000000).get();
				Element content = doc1.getElementById("twocol");
				Elements content1 = doc1.getElementsByTag("p");  
				Element content2 = doc1.getElementsByTag("h2").first();
				String name = content2.text();
				String Introduction = content.text();		    	
				String ctt1 = content1.text();
				String regex1 = "(\\d{1}-\\d{3}-\\d{3}-\\d{4})";
				String regex2 = "[a-z]+@([a-z]+)\\.([a-z]+)\\.([a-z]+)|[a-z]+@([a-z]+)\\.([a-z]+)";
				Matcher matcher1 = Pattern.compile(regex1).matcher(ctt1);
				if(matcher1.find()){
					PhoneNumber = matcher1.group(0);
				}else{
					PhoneNumber = " ";
				}
				Matcher matcher2 = Pattern.compile(regex2).matcher(ctt1);
				if(matcher2.find()){
					Email = matcher2.group(0);
				}else{
					Email = " ";
				}
				PreparedStatement insertInfor = con.prepareStatement("insert into proinfo3 values(?,?,?,?,?)");
				insertInfor.setInt(1,++m);
				insertInfor.setString(2, name);
				insertInfor.setString(3, PhoneNumber);
				insertInfor.setString(4, Email);
				insertInfor.setString(5, Introduction);
				insertInfor.executeUpdate();
			}
		}
		con.close();	
	}
	@SuppressWarnings("static-access")
	public void run(){
		long startTimeStamp =  System.currentTimeMillis();
		try {
			this.parsepage();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Processing Time: " + Long.toString(System.currentTimeMillis() - startTimeStamp));

	}


}
